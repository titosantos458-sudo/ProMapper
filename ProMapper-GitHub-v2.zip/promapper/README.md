# ProMapper

Projeto Android do ProMapper.

## Gerar APK pelo GitHub

1. Envie os arquivos do projeto para a raiz do repositório.
2. O workflow `.github/workflows/build-apk.yml` executa manualmente ou a cada push em `main`/`master`.
3. Em **Actions**, abra **Build ProMapper APK**.
4. Ao terminar com sucesso, baixe o artefato **ProMapper-debug-apk**.
